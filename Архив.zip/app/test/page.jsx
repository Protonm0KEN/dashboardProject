import React from 'react'
const Page = () => {
    return (
        <div>
            <form action="">
                <input name='username' type="text"/>
                <button>Send</button>
            </form>
        </div>
    )
}

export default Page